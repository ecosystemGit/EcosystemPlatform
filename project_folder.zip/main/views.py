from django.shortcuts import render
from .models import Entrepreneur, Category


def home(request):
    entrepreneurs = Entrepreneur.objects.all()
    context = {
        "entrepreneurs":entrepreneurs,
    }
    return render(request, "home.html", context)