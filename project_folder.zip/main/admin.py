from django.contrib import admin
from .models import Entrepreneur, Category
# Register your models here.
admin.site.register(Entrepreneur)
admin.site.register(Category)