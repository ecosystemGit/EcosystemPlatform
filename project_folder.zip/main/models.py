from django.db import models
from django.contrib.auth import get_user_model
from django.urls import reverse
from django_resized import ResizedImageField
from django.contrib.sites.models import Site

current_site = Site.objects.get_current()

User = get_user_model()


class Category(models.Model):
    title = models.CharField(max_length=20)

    def __str__(self):
        return self.title
    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"


class Entrepreneur(models.Model):
    name = models.CharField(max_length=300)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    logo = ResizedImageField(size=[500, 300],upload_to="")
    x_location = models.CharField(max_length=20)
    y_location = models.CharField(max_length=20)
    website = models.CharField(max_length=300, blank=True, null=True)
    categories = models.ManyToManyField(Category)
    created = models.CharField(max_length=50)
    country = models.CharField(max_length=100)
    email = models.CharField(max_length=200)
    phone = models.CharField(max_length=20, blank=True, null=True)
    description = models.TextField()

    def __str__(self):
        return self.name

    @property
    def image_path(self):
        return current_site.domain+self.logo.url

